import requests
from xml.etree import ElementTree
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

druid_username = os.environ['druid_username']
druid_pword = os.environ['druid_pword']


def handler(event, context):
    """Retrieve namespace / source information from ID systems proxied."""
    sources = []
    logger.info('Starting a DRUID Namespace call.')

    # Handle DRUIDs

    ns_request = "https://{0}:{1}@sul-lyberservices-test.stanford.edu/suri2/namespaces/druid"
    logger.info('Calling lyberservices test.')
    resp = requests.get(ns_request.format(druid_username, druid_pword)).content
    tree = ElementTree.fromstring(resp)
    logger.info('Parsing SURI response.')
    for ns in tree.iter('namespace'):
        source = {}
        source['name'] = ns.find('name').text
        source['template'] = ns.find('template').text
        sources.append(source)

    return(sources)
